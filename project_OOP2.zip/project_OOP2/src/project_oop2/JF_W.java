package project_oop2;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import javax.swing.*;
import java.lang.System;

public class JF_W extends JFrame implements ActionListener{
private JFrame Frame1;
private JLabel label_1 , label_2, Blank ;
private JPanel panel1, panel2 ,panel3, panel4;
private JRadioButton rb1 ,rb2 ,rb3 ;
private JButton btn1;

 // menubar
    static JMenuBar mb ;
 
    // JMenu
    static JMenu x,mmb2;
 
    // Menu items
    static JMenuItem m1, m2,mm1,mm2;
 
    // create a frame
  
public  JF_W (){
    
      Frame1 = new JFrame();

Image icon = Toolkit.getDefaultToolkit().getImage("IconH.jpg");    
Frame1.setIconImage(icon);

        // create a menubar
        mb = new JMenuBar();
        // create a menu
        x = new JMenu("Menu");
        mmb2 = new JMenu("Soon");
        // create menuitems
        m1 = new JMenuItem("About the program");
        m2 = new JMenuItem("Contact us");
         mm1 = new JMenuItem("Soon1");
        mm2 = new JMenuItem("Soon2");
        // add menu items to menu
        x.add(m1);
        x.add(m2);
         mmb2.add(mm1);
        mmb2.add(mm2);
        // add menu to menu bar
        mb.add(x);
        mb.add(mmb2);
       // add menubar to frame
        Frame1.setJMenuBar(mb);

              
                    panel1 = new JPanel();
                    panel2 = new JPanel();
                    panel3 = new JPanel();
                    panel4 = new JPanel();

    label_1= new JLabel("**WELCOME**");
    label_2 = new JLabel("Please choose one of these option");
    Blank = new JLabel("                                                    ");
    rb1= new JRadioButton("1. Sell a house");
    rb2= new JRadioButton("2. Buy a house");
    rb3= new JRadioButton("3. Exit");
    btn1 = new JButton("Choose");
        ButtonGroup group = new ButtonGroup();
        group.add(rb1);
        group.add(rb2);
        group.add(rb3);


                            panel1.add(label_1);
                            panel2.add(label_2);
                            panel3.add(rb1);
                            panel3.add(rb2);
                            panel3.add(rb3);
                            panel4.add(btn1);
 

                                                Frame1.add(panel1);
                                                Frame1.add(panel2);
                                                Frame1.add(Blank);
                                                Frame1.add(panel3);
                                                Frame1.add(panel4);


    Frame1.setLayout(new GridLayout(6,1));
    Frame1.setSize(350,250);
    Frame1.setTitle("RealEstate Programm");
    Frame1.setDefaultCloseOperation(EXIT_ON_CLOSE);                              
    Frame1.setLocationRelativeTo(null);
Frame1.setBackground(Color.yellow);
    Frame1.setVisible(true);

m1.addActionListener((ae) -> {
m1.isSelected();{
menu B =new menu();
B.setVisible(true);

}
});

m2.addActionListener((ae) -> {
CosteSer Co = new CosteSer();
Co.setVisible(true);
});
btn1.addActionListener(this);

}

public void actionPerformed(ActionEvent e) {
// Selcet Sell 
if (rb1.isSelected()){
JF_W2 B = new JF_W2();
B.setVisible(true);
Frame1.dispose();
}// Select Buy 
else if (rb2.isSelected()){
try{

DisplayH BB = new DisplayH ();
BB.setVisible(true);
Frame1.dispose();

}catch(Exception A){
}

}
else if (rb3.isSelected()){
// end the programm
    System.exit(0);
}

}


}
