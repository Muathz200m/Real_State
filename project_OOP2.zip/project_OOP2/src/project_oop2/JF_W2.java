/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project_oop2;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.*;
import java.util.*;



/**
 *
 * @author M0zs
 */
public class JF_W2 extends JFrame implements ActionListener{

private JLabel label_21,label_22,label_23,label_24,label_25,label_26,label_27 , label_00;
private JTextField textf21,textf22,textf23,textf24,textf25,textf26,textf27;
private JPanel panel21, panel22 ,panel23, panel24,panel25,panel26,panel27,panel28 ;
private JButton btnInD;
private JSlider AgeS;
int i  ;
public JF_W2 (){

    
Image icon = Toolkit.getDefaultToolkit().getImage("IconH.jpg");    
this.setIconImage(icon);    

    label_21= new JLabel("");
AgeS = new JSlider(JSlider.HORIZONTAL,20,60,40);
AgeS.setMinorTickSpacing(2);
AgeS.setMajorTickSpacing(10);
AgeS.setPaintTicks(true);
AgeS.setPaintLabels(true);
    label_21 = new JLabel("Enter name:");
    label_22 = new JLabel("Enter mobile number:");
    label_23 = new JLabel("Enter age:");
    label_24 = new JLabel("Enter price ﷼    :   ");
    label_25 = new JLabel("Enter number of floors:");
    label_26 = new JLabel("Enter neighborhood:");
    label_27 = new JLabel("Enter plot number:");

                    textf21 = new JTextField(11);
                    textf22 = new JTextField(11);
                    textf23 = new JTextField(11);
                    textf24 = new JTextField(11);
                    textf25 = new JTextField(11);
                    textf26 = new JTextField(11);
                    textf27 = new JTextField(11);

label_00 = new JLabel("Please check the data before confirm");
btnInD = new JButton("Confirm");


panel21 = new JPanel();
panel22 = new JPanel();
panel23 = new JPanel();
panel24 = new JPanel();
panel25 = new JPanel();
panel26 = new JPanel();
panel27 = new JPanel();
panel28 = new JPanel();


panel21.add(label_21);
panel21.add(textf21);

panel22.add(label_22);
panel22.add(textf22);
 
panel23.add(label_23);
panel23.add(AgeS);

panel24.add(label_24);
panel24.add(textf24);

panel25.add(label_25);
panel25.add(textf25);

panel26.add(label_26);
panel26.add(textf26);


panel27.add(label_27);
panel27.add(textf27);

panel28.add(label_00);
panel28.add(btnInD);

                               this.setLayout(new GridLayout(8,2) );
                                this.setSize(350,550);
                                this.setTitle("Seller information");
                                this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);                              
                                this.setLocationRelativeTo(null);
this.setResizable(false);
                           
this.add(panel21);
this.add(panel22);
this.add(panel23);
this.add(panel24);
this.add(panel25);
this.add(panel26);
this.add(panel27);
this.add(panel28);

  this.setVisible(true);
btnInD.addActionListener(this);

textf22.addKeyListener (new KeyAdapter(){
 public void keyPressed(KeyEvent ke) {
            String value = textf22.getText();
            int l = value.length();
            if (ke.getKeyChar() >= '0' && ke.getKeyChar() <= '9'|| ke.getKeyChar() == KeyEvent.VK_SPACE ||ke.getKeyChar() == KeyEvent.VK_BACK_SPACE) {
            } else {
                textf22.setEditable(false);
JOptionPane.showMessageDialog(null, "* Enter only numeric digits(0-9)");
               textf22.setEditable(true);
            }
         }
});
textf24.addKeyListener (new KeyAdapter(){
 public void keyPressed(KeyEvent ke) {
            String value = textf24.getText();
            int l = value.length();
            if (ke.getKeyChar() >= '0' && ke.getKeyChar() <= '9'|| ke.getKeyChar() == KeyEvent.VK_SPACE ||ke.getKeyChar() == KeyEvent.VK_BACK_SPACE) {
            } else {
                textf24.setEditable(false);
JOptionPane.showMessageDialog(null, "* Enter only numeric digits(0-9)");
               textf24.setEditable(true);
            }
         }
});
textf25.addKeyListener (new KeyAdapter(){
 public void keyPressed(KeyEvent ke) {
            String value = textf25.getText();
            int l = value.length();
            if (ke.getKeyChar() >= '0' && ke.getKeyChar() <= '9'|| ke.getKeyChar() == KeyEvent.VK_SPACE ||ke.getKeyChar() == KeyEvent.VK_BACK_SPACE) {
            } else {
                textf25.setEditable(false);
JOptionPane.showMessageDialog(null, "* Enter only numeric digits(0-9)");
               textf25.setEditable(true);
            }
         }
});

}
public void actionPerformed(ActionEvent e) {
if (textf21.getText().isEmpty() && textf22.getText().isEmpty()&& textf23.getText().isEmpty()&& textf24.getText().isEmpty()&& textf25.getText().isEmpty()&& textf26.getText().isEmpty()&& textf27.getText().isEmpty() ){
JOptionPane.showMessageDialog(null, "Please complete all feild");  
}else{
btnInD.isSelected();{

try{
String name = textf21.getText();
String phone  = textf22.getText();
String age = String.valueOf(AgeS.getValue());// take value from slider to file 
String price = textf24.getText();
String floors = textf25.getText();
String neighborhood = textf26.getText();
String plot = textf27.getText();


 

   writeToFile(neighborhood, floors,plot ,price ,"Sell.H.Data.txt");

writeToFile2(name, phone, age,"Sell.C.Data.txt");
}
catch (IOException Z){
Z.getMessage();
    System.out.println("Error in insert info to file");
}
}
JOptionPane.showMessageDialog(null, "   Thank you ^_^  ");
dispose();
JF_W G = new JF_W();

}

}


public static void writeToFile2( String name, String phone, String age ,String filename)  {
       try {
 
 FileOutputStream fileOutputStream2 = new FileOutputStream(filename, true);
        String str2 = String.format("%10s / %10s / %10s  \n",name,phone,age);
        fileOutputStream2.write(str2.getBytes());
        fileOutputStream2.close();
}catch(IOException A){
A.getMessage();
}
}

public static void writeToFile( String neighborhood, String floors, String plot , String price,String filename ) throws IOException {
try {

FileOutputStream fileOutputStream = new FileOutputStream(filename, true);
String str ;

         str = String.format("%10s / %10s / %10s / %10s  \n",neighborhood,floors,plot,price);

 fileOutputStream.write(str.getBytes());
        fileOutputStream.close();
}catch(IOException A){
A.getMessage();
}
 }

}
