/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project_oop2;


import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.FileOutputStream;
import java.io.IOException;
import javax.swing.JButton;
import javax.swing.JFrame;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;



/**
 *
 * @author M0zs
 */
public class BuyerD extends JFrame implements ActionListener{
//private JFrame Frame4 ;
private JLabel labelA,labelName,labelNum,labelAge,labelBlank;    
private JTextField ntext , numtext , agetext ;
private JButton btn ;

public BuyerD (){
Image icon = Toolkit.getDefaultToolkit().getImage("IconH.jpg");    
this.setIconImage(icon);
dispose();

 labelA = new JLabel("  Please neter your Information so the owner will be able to contact you:- ");
 labelName = new JLabel("  Full name: ");
 labelNum = new JLabel("  Phone Number: ");
 labelAge = new JLabel("  Age: ");
 labelBlank = new JLabel("              ");
 ntext = new JTextField(9);
 numtext = new JTextField(9);
 agetext = new JTextField(9);

btn = new JButton(" Send request   :) ");




this.setLayout(new GridLayout(9,1));
   this.setSize(650,420);
    this.setTitle("Buyer Information");
    this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);                              
    this.setLocationRelativeTo(null);
this.add(labelA);
this.add(labelName);
this.add(ntext);
this.add(labelNum);
this.add(numtext);
this.add(labelAge);
this.add(agetext);
this.add(labelBlank);
this.add(btn);
    this.setVisible(true);

btn.addActionListener(this);

numtext.addKeyListener (new KeyAdapter(){
 public void keyPressed(KeyEvent ke) {
           
if (ke.getKeyChar() >= '0' && ke.getKeyChar() <= '9' ||ke.getKeyCode() == KeyEvent.VK_BACK_SPACE || ke.getKeyCode() == KeyEvent.VK_SPACE  ) {
            } else {
    numtext.setEditable(false);
JOptionPane.showMessageDialog(null, "* Enter only numeric digits(0-9)");
numtext.setEditable(true);
            }
         }
});
agetext.addKeyListener (new KeyAdapter(){
 public void keyPressed(KeyEvent ke) {
//     System.out.println(ke);
            String value = agetext.getText();
            int l = value.length();
            if (ke.getKeyChar() >= '0' && ke.getKeyChar() <= '9' ||ke.getKeyCode() == KeyEvent.VK_BACK_SPACE || ke.getKeyCode() == KeyEvent.VK_SPACE  ) {

            } else {
               agetext.setEditable(false);
JOptionPane.showMessageDialog(null, "* Enter only numeric digits(0-9)");
agetext.setEditable(true);
            }
         }
});



}
public void actionPerformed(ActionEvent e) {
 
if (ntext.getText().isEmpty() && numtext.getText().isEmpty()&& agetext.getText().isEmpty() ){
JOptionPane.showMessageDialog(null, "Please complete all feild");
}else{

String name = ntext.getText();
String phone  = numtext.getText();
String age = agetext.getText();
JOptionPane.showMessageDialog(null, "thank you the owner well contact you " );
writeToFile2(name, phone, age,"Buyer_Data.txt");
System.exit(0);

}
}
public static void writeToFile2( String name,String phone, String age ,String filename)  {
       try {

 FileOutputStream fileOutputStream2 = new FileOutputStream(filename, true);
        String str2 = String.format("%10s / %10s / %10s  \n",name,phone,age);
        fileOutputStream2.write(str2.getBytes());
        fileOutputStream2.close();
}catch(IOException A){
A.getMessage();
}
}
}
