/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package project_oop2;
public class Project_OOP2 {
    public static void main(String[] args) {
JF_W A = new JF_W();
//JF_W2 B = new JF_W2();
    }  }
